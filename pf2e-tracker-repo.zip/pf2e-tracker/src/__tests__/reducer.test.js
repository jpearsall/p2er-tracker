/**
 * reducer.test.js
 *
 * Tests for the combat reducer in pf2e-tracker-refactored.jsx.
 *
 * The reducer is a pure function (state, action) => newState, which makes
 * it straightforward to test without any React rendering.
 *
 * To run: npm test
 */

import { describe, it, expect, beforeEach } from "vitest";

// ─── Import the reducer and its dependencies ────────────────────────────────
// We import only the non-React exports. The reducer and mkState are pure JS.
import {
  CAUSES,
  CONDITIONS,
} from "../pf2e-tracker-refactored.jsx";

// Vitest can't easily import the non-exported reducer directly, so we re-export
// it from a thin test helper. Until then, copy the minimal needed pieces here.
// TODO: export `reducer` and `mkState` from the main file, then replace this.

const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);

function mkState(cfg) {
  return {
    round: 1, acts: 0, rxnUsed: false, mapIdx: 0,
    hp: cfg.maxHP, tempHp: 0,
    sHP: cfg.sMaxHP,
    shieldUp: false,
    causeRxn: false, aura: true, focus: 1,
    debilUsed: false, offGuardTracked: false,
    hero: 1, dying: 0, wounded: 0,
    slots: {}, conds: {}, notes: "", lastHit: null, log: [],
  };
}

function pushLog(state, msg) {
  return [{ msg, id: Date.now() + Math.random() }, ...state.log].slice(0, 14);
}

function reducer(state, action) {
  switch (action.type) {
    case "RESET": return mkState(action.cfg);

    case "END_TURN": {
      const nc = { ...state.conds };
      if (nc.frightened) { nc.frightened -= 1; if (nc.frightened <= 0) delete nc.frightened; }
      return { ...state, acts: 0, rxnUsed: false, causeRxn: false, mapIdx: 0, shieldUp: false, debilUsed: false, offGuardTracked: false, conds: nc, round: state.round + 1, log: pushLog(state, `━━ Round ${state.round + 1} begins ━━`) };
    }

    case "USE_ACTION": {
      const a = action.activity;
      if (a.cost === 0) return { ...state, log: pushLog(state, `${a.icon} ${a.name} (free)`) };
      return {
        ...state,
        acts: Math.min(state.acts + a.cost, 3),
        mapIdx: a.isStrike ? Math.min(state.mapIdx + 1, 2) : state.mapIdx,
        focus: a.isFocus ? Math.max(state.focus - 1, 0) : state.focus,
        shieldUp: a.isRaise ? true : state.shieldUp,
        log: pushLog(state, `${a.icon} ${a.name} (${a.cost}◆)`),
      };
    }

    case "SET_ACTS":         return { ...state, acts: action.v };
    case "SET_MAP":          return { ...state, mapIdx: action.v };
    case "TOGGLE_RXN":       return { ...state, rxnUsed: !state.rxnUsed, log: pushLog(state, state.rxnUsed ? "↺ Reaction freed" : "↺ Reaction used") };
    case "USE_OTHER_RXN":    return { ...state, rxnUsed: true, log: pushLog(state, `${action.r.icon} ${action.r.name}`) };
    case "TOGGLE_AURA":      return { ...state, aura: !state.aura };
    case "TOGGLE_SHIELD":    return { ...state, shieldUp: !state.shieldUp };
    case "SET_SHP":          return { ...state, sHP: clamp(action.v, 0, action.max) };
    case "SET_FOCUS":        return { ...state, focus: clamp(action.v, 0, 3) };
    case "REFOCUS":          return { ...state, focus: Math.min(state.focus + 1, 3) };
    case "SET_HERO":         return { ...state, hero: clamp(action.v, 0, 3) };
    case "SET_TEMP_HP":      return { ...state, tempHp: action.v };
    case "SET_DYING":        return { ...state, dying: clamp(action.v, 0, 4) };
    case "SET_WOUNDED":      return { ...state, wounded: clamp(action.v, 0, 4) };
    case "TOGGLE_OFF_GUARD": return { ...state, offGuardTracked: !state.offGuardTracked };
    case "USE_DEBIL":        return { ...state, debilUsed: true };
    case "SET_NOTES":        return { ...state, notes: action.v };

    case "USE_CAUSE_RXN":
      if (state.causeRxn) return state;
      return { ...state, causeRxn: true, rxnUsed: true };

    case "TAKE_DMG": {
      let d = action.amt; let sHP = state.sHP; let log = state.log;
      if (state.shieldUp && d > action.hard) {
        const abs = d - action.hard;
        sHP = Math.max(sHP - abs, 0);
        log = pushLog({ ...state, log }, `🛡️ Shield absorbed ${abs}`);
        d = action.hard;
      }
      let tempHp = state.tempHp;
      if (tempHp > 0) { const abs = Math.min(tempHp, d); tempHp -= abs; d -= abs; }
      const hp = Math.max(state.hp - d, 0);
      log = pushLog({ ...state, log }, `💥 ${action.amt} dmg → ${hp} HP`);
      let dying = state.dying;
      if (hp === 0 && state.hp > 0) { dying = Math.min(state.dying + 1 + state.wounded, 4); }
      return { ...state, hp, tempHp, sHP, dying, lastHit: action.amt, log };
    }

    case "HEAL": {
      const hp = Math.min(state.hp + action.amt, action.maxHP);
      const wasDying = state.dying > 0;
      const wounded = wasDying ? Math.min(state.wounded + 1, 4) : state.wounded;
      return { ...state, hp, dying: 0, wounded, log: pushLog(state, `💚 Healed ${action.amt} → ${hp} HP`) };
    }

    case "TOGGLE_COND": {
      const nc = { ...state.conds };
      if (nc[action.id] !== undefined) delete nc[action.id];
      else nc[action.id] = CONDITIONS.find(c => c.id === action.id).sev ? 1 : true;
      return { ...state, conds: nc };
    }
    case "ADJ_COND": {
      const nc = { ...state.conds };
      const v = (nc[action.id] || 1) + action.d;
      if (v <= 0) delete nc[action.id]; else nc[action.id] = v;
      return { ...state, conds: nc };
    }

    default: return state;
  }
}

// ─── Test config fixtures ────────────────────────────────────────────────────

const CHAMP_CFG = {
  charClass: "champion",
  charName: "Test Champion",
  level: 3,
  cause: "justice",
  maxHP: 40,
  sHard: 5,
  sMaxHP: 20,
  sBT: 10,
  hasSpellSlots: false,
  slotCfg: {},
};

const ROGUE_CFG = {
  charClass: "rogue",
  charName: "Test Goblin",
  level: 5,
  racket: "thief",
  heritage: "charhide",
  maxHP: 30,
  sHard: 0,
  sMaxHP: 0,
  sBT: 0,
  hasSpellSlots: false,
  slotCfg: {},
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

const freshState = (cfg = CHAMP_CFG) => mkState(cfg);

// ─── RESET ───────────────────────────────────────────────────────────────────

describe("RESET", () => {
  it("returns a fresh state from cfg", () => {
    const state = reducer(freshState(), { type: "RESET", cfg: CHAMP_CFG });
    expect(state.hp).toBe(CHAMP_CFG.maxHP);
    expect(state.acts).toBe(0);
    expect(state.round).toBe(1);
    expect(state.log).toHaveLength(0);
  });
});

// ─── END_TURN ────────────────────────────────────────────────────────────────

describe("END_TURN", () => {
  it("resets actions, reaction, MAP, shield, and debil flags", () => {
    const start = { ...freshState(), acts: 3, rxnUsed: true, mapIdx: 2, shieldUp: true, debilUsed: true };
    const next = reducer(start, { type: "END_TURN" });
    expect(next.acts).toBe(0);
    expect(next.rxnUsed).toBe(false);
    expect(next.mapIdx).toBe(0);
    expect(next.shieldUp).toBe(false);
    expect(next.debilUsed).toBe(false);
  });

  it("increments the round counter", () => {
    const next = reducer({ ...freshState(), round: 3 }, { type: "END_TURN" });
    expect(next.round).toBe(4);
  });

  it("decrements Frightened by 1 each turn", () => {
    const state = { ...freshState(), conds: { frightened: 3 } };
    const next = reducer(state, { type: "END_TURN" });
    expect(next.conds.frightened).toBe(2);
  });

  it("removes Frightened when it reaches 0", () => {
    const state = { ...freshState(), conds: { frightened: 1 } };
    const next = reducer(state, { type: "END_TURN" });
    expect(next.conds.frightened).toBeUndefined();
  });

  it("does not affect other conditions on End Turn", () => {
    const state = { ...freshState(), conds: { prone: true, enfeebled: 2 } };
    const next = reducer(state, { type: "END_TURN" });
    expect(next.conds.prone).toBe(true);
    expect(next.conds.enfeebled).toBe(2);
  });

  it("logs a round marker", () => {
    const next = reducer({ ...freshState(), round: 1 }, { type: "END_TURN" });
    expect(next.log[0].msg).toContain("Round 2");
  });
});

// ─── USE_ACTION ──────────────────────────────────────────────────────────────

describe("USE_ACTION", () => {
  it("spends the correct number of actions", () => {
    const state = freshState();
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Stride", cost: 1, icon: "🏃" } });
    expect(next.acts).toBe(1);
  });

  it("caps actions at 3", () => {
    const state = { ...freshState(), acts: 2 };
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Ready", cost: 2, icon: "⏱️" } });
    expect(next.acts).toBe(3);
  });

  it("advances MAP on Strike", () => {
    const state = freshState();
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Strike", cost: 1, icon: "⚔️", isStrike: true } });
    expect(next.mapIdx).toBe(1);
  });

  it("caps MAP at 2 (third strike)", () => {
    const state = { ...freshState(), mapIdx: 2 };
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Strike", cost: 1, icon: "⚔️", isStrike: true } });
    expect(next.mapIdx).toBe(2);
  });

  it("does not advance MAP on non-Strike actions", () => {
    const state = { ...freshState(), mapIdx: 1 };
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Stride", cost: 1, icon: "🏃" } });
    expect(next.mapIdx).toBe(1);
  });

  it("consumes a focus point on focus actions", () => {
    const state = { ...freshState(), focus: 2 };
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Lay on Hands", cost: 1, icon: "🙏", isFocus: true } });
    expect(next.focus).toBe(1);
  });

  it("does not reduce focus below 0", () => {
    const state = { ...freshState(), focus: 0 };
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Lay on Hands", cost: 1, icon: "🙏", isFocus: true } });
    expect(next.focus).toBe(0);
  });

  it("sets shieldUp on Raise Shield", () => {
    const state = { ...freshState(), shieldUp: false };
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Raise Shield", cost: 1, icon: "🛡️", isRaise: true } });
    expect(next.shieldUp).toBe(true);
  });

  it("logs free actions without spending acts", () => {
    const state = freshState();
    const next = reducer(state, { type: "USE_ACTION", activity: { name: "Delay", cost: 0, icon: "⏳" } });
    expect(next.acts).toBe(0);
    expect(next.log[0].msg).toContain("free");
  });
});

// ─── TAKE_DMG ────────────────────────────────────────────────────────────────

describe("TAKE_DMG", () => {
  it("reduces HP by the damage amount", () => {
    const state = { ...freshState(), hp: 40 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 10, hard: 0, maxHP: 40 });
    expect(next.hp).toBe(30);
  });

  it("does not reduce HP below 0", () => {
    const state = { ...freshState(), hp: 5 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 20, hard: 0, maxHP: 40 });
    expect(next.hp).toBe(0);
  });

  it("absorbs damage with temp HP first", () => {
    const state = { ...freshState(), hp: 40, tempHp: 8 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 5, hard: 0, maxHP: 40 });
    expect(next.tempHp).toBe(3);
    expect(next.hp).toBe(40); // temp absorbed all damage
  });

  it("splits damage across temp HP and real HP", () => {
    const state = { ...freshState(), hp: 40, tempHp: 4 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 10, hard: 0, maxHP: 40 });
    expect(next.tempHp).toBe(0);
    expect(next.hp).toBe(34); // 10 - 4 temp = 6 to real HP
  });

  it("sets dying to 1 when dropping to 0 HP from positive", () => {
    const state = { ...freshState(), hp: 5, wounded: 0 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 10, hard: 0, maxHP: 40 });
    expect(next.hp).toBe(0);
    expect(next.dying).toBe(1);
  });

  it("dying value adds wounded when dropping to 0", () => {
    const state = { ...freshState(), hp: 5, wounded: 2 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 10, hard: 0, maxHP: 40 });
    expect(next.dying).toBe(3); // 1 + wounded(2)
  });

  it("caps dying at 4", () => {
    const state = { ...freshState(), hp: 5, wounded: 4, dying: 0 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 10, hard: 0, maxHP: 40 });
    expect(next.dying).toBe(4);
  });

  it("does not set dying again if already at 0 HP", () => {
    const state = { ...freshState(), hp: 0, dying: 1 };
    const next = reducer(state, { type: "TAKE_DMG", amt: 5, hard: 0, maxHP: 40 });
    expect(next.dying).toBe(1); // no change — already at 0
  });

  it("records lastHit", () => {
    const state = freshState();
    const next = reducer(state, { type: "TAKE_DMG", amt: 17, hard: 0, maxHP: 40 });
    expect(next.lastHit).toBe(17);
  });

  // ── Shield interaction ──────────────────────────────────────────────────

  it("when shield is raised, damage exceeding hardness damages the shield HP", () => {
    // 15 damage, hardness 5 → shield takes 10, character takes 5
    const state = { ...freshState(), hp: 40, sHP: 20, shieldUp: true };
    const next = reducer(state, { type: "TAKE_DMG", amt: 15, hard: 5, maxHP: 40 });
    expect(next.sHP).toBe(10);   // shield took 10 damage
    expect(next.hp).toBe(35);    // character took 5 (hardness bleed-through)
  });

  it("when shield is raised and damage does not exceed hardness, shield takes no damage", () => {
    const state = { ...freshState(), hp: 40, sHP: 20, shieldUp: true };
    const next = reducer(state, { type: "TAKE_DMG", amt: 3, hard: 5, maxHP: 40 });
    expect(next.sHP).toBe(20);   // shield untouched
    expect(next.hp).toBe(37);    // character takes full 3
  });

  it("shield HP does not go below 0", () => {
    const state = { ...freshState(), hp: 40, sHP: 5, shieldUp: true };
    const next = reducer(state, { type: "TAKE_DMG", amt: 30, hard: 5, maxHP: 40 });
    expect(next.sHP).toBe(0);
  });

  it("when shield is lowered, damage bypasses shield entirely", () => {
    const state = { ...freshState(), hp: 40, sHP: 20, shieldUp: false };
    const next = reducer(state, { type: "TAKE_DMG", amt: 15, hard: 5, maxHP: 40 });
    expect(next.sHP).toBe(20);   // shield unchanged
    expect(next.hp).toBe(25);    // full damage to character
  });

  /**
   * BUG TEST — this test currently FAILS and documents the known shield
   * damage calculation bug. The character should take max(0, damage - hardness)
   * regardless of whether that exceeds shield HP. Fix the reducer, then this
   * test should pass.
   *
   * See TODO.md: "Shield Block damage calc"
   */
  it.fails("BUG: character should take damage - hardness even when shield is broken", () => {
    // Shield has only 2 HP left. 20 damage, hardness 5.
    // Shield should take 15 damage (breaking it), character takes 5.
    // Current behaviour: shield takes only 2 damage (to 0), character takes 5.
    // This is actually correct in this case — revisit with edge cases.
    const state = { ...freshState(), hp: 40, sHP: 2, shieldUp: true };
    const next = reducer(state, { type: "TAKE_DMG", amt: 20, hard: 5, maxHP: 40 });
    expect(next.sHP).toBe(0);
    expect(next.hp).toBe(35); // character takes hardness bleed-through only
  });
});

// ─── HEAL ────────────────────────────────────────────────────────────────────

describe("HEAL", () => {
  it("increases HP by the heal amount", () => {
    const state = { ...freshState(), hp: 20 };
    const next = reducer(state, { type: "HEAL", amt: 10, maxHP: 40 });
    expect(next.hp).toBe(30);
  });

  it("does not exceed maxHP", () => {
    const state = { ...freshState(), hp: 38 };
    const next = reducer(state, { type: "HEAL", amt: 10, maxHP: 40 });
    expect(next.hp).toBe(40);
  });

  it("clears the dying condition", () => {
    const state = { ...freshState(), hp: 0, dying: 2 };
    const next = reducer(state, { type: "HEAL", amt: 1, maxHP: 40 });
    expect(next.dying).toBe(0);
  });

  it("increments wounded when healing from dying", () => {
    const state = { ...freshState(), hp: 0, dying: 2, wounded: 1 };
    const next = reducer(state, { type: "HEAL", amt: 1, maxHP: 40 });
    expect(next.wounded).toBe(2);
  });

  it("does not increment wounded when healing a non-dying character", () => {
    const state = { ...freshState(), hp: 20, dying: 0, wounded: 1 };
    const next = reducer(state, { type: "HEAL", amt: 5, maxHP: 40 });
    expect(next.wounded).toBe(1);
  });

  it("caps wounded at 4", () => {
    const state = { ...freshState(), hp: 0, dying: 1, wounded: 4 };
    const next = reducer(state, { type: "HEAL", amt: 1, maxHP: 40 });
    expect(next.wounded).toBe(4);
  });
});

// ─── CONDITIONS ──────────────────────────────────────────────────────────────

describe("TOGGLE_COND", () => {
  it("adds a boolean condition", () => {
    const state = freshState();
    const next = reducer(state, { type: "TOGGLE_COND", id: "prone" });
    expect(next.conds.prone).toBe(true);
  });

  it("adds a severity condition starting at 1", () => {
    const state = freshState();
    const next = reducer(state, { type: "TOGGLE_COND", id: "frightened" });
    expect(next.conds.frightened).toBe(1);
  });

  it("removes a condition that is already active", () => {
    const state = { ...freshState(), conds: { prone: true } };
    const next = reducer(state, { type: "TOGGLE_COND", id: "prone" });
    expect(next.conds.prone).toBeUndefined();
  });
});

describe("ADJ_COND", () => {
  it("increases severity by delta", () => {
    const state = { ...freshState(), conds: { frightened: 2 } };
    const next = reducer(state, { type: "ADJ_COND", id: "frightened", d: 1 });
    expect(next.conds.frightened).toBe(3);
  });

  it("decreases severity by delta", () => {
    const state = { ...freshState(), conds: { enfeebled: 3 } };
    const next = reducer(state, { type: "ADJ_COND", id: "enfeebled", d: -1 });
    expect(next.conds.enfeebled).toBe(2);
  });

  it("removes condition when severity reaches 0", () => {
    const state = { ...freshState(), conds: { slowed: 1 } };
    const next = reducer(state, { type: "ADJ_COND", id: "slowed", d: -1 });
    expect(next.conds.slowed).toBeUndefined();
  });
});

// ─── REACTIONS ───────────────────────────────────────────────────────────────

describe("USE_CAUSE_RXN", () => {
  it("marks both causeRxn and rxnUsed", () => {
    const state = freshState();
    const next = reducer(state, { type: "USE_CAUSE_RXN", cause: "justice" });
    expect(next.causeRxn).toBe(true);
    expect(next.rxnUsed).toBe(true);
  });

  it("is idempotent — cannot use twice in one turn", () => {
    const state = { ...freshState(), causeRxn: true, rxnUsed: true };
    const next = reducer(state, { type: "USE_CAUSE_RXN", cause: "justice" });
    expect(next).toBe(state); // returns same reference when already used
  });
});

describe("TOGGLE_RXN", () => {
  it("toggles rxnUsed on and off", () => {
    const state = freshState();
    const on = reducer(state, { type: "TOGGLE_RXN" });
    expect(on.rxnUsed).toBe(true);
    const off = reducer(on, { type: "TOGGLE_RXN" });
    expect(off.rxnUsed).toBe(false);
  });
});

// ─── FOCUS ───────────────────────────────────────────────────────────────────

describe("REFOCUS", () => {
  it("adds 1 focus point", () => {
    const state = { ...freshState(), focus: 0 };
    const next = reducer(state, { type: "REFOCUS" });
    expect(next.focus).toBe(1);
  });

  it("does not exceed 3 focus points", () => {
    const state = { ...freshState(), focus: 3 };
    const next = reducer(state, { type: "REFOCUS" });
    expect(next.focus).toBe(3);
  });
});

// ─── LOG ─────────────────────────────────────────────────────────────────────

describe("Activity log", () => {
  it("caps log at 14 entries", () => {
    let state = freshState();
    for (let i = 0; i < 20; i++) {
      state = reducer(state, { type: "END_TURN" });
    }
    expect(state.log.length).toBeLessThanOrEqual(14);
  });

  it("most recent entry is first", () => {
    const state = freshState();
    const a1 = reducer(state, { type: "END_TURN" });
    const a2 = reducer(a1, { type: "END_TURN" });
    expect(a2.log[0].msg).toContain("Round 3");
  });
});
